from django.shortcuts import render

# Create your views here.
def home_view(request):
    return render(request, 'main.html', {})

# Create your views here.
def index_view(request):
    return render(request, 'index.html', {})
# Create your views here.
def creative_view(request):
    return render(request, 'creative.html', {})